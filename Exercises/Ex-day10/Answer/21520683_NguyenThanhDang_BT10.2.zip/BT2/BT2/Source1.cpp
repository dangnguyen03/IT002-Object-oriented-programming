﻿#include <iostream>
#include <vector>
#include <time.h>
#include <string>
#include <vector>

using namespace std;

class GiaSuc
{

public:
	GiaSuc(void);
	~GiaSuc(void);
	virtual void Keu(void) = 0;
	virtual int ChoSua(void) = 0;
	virtual vector<GiaSuc*> SinhCon(void) = 0;
protected:
	// Loại gia súc, Bò = 1, Cừu = 2, Dê = 3
	int m_iLoai;
public:
	int LoaiGiaSuc(void);
	virtual string TenLoai(void) = 0;
};

GiaSuc::GiaSuc(void)
	: m_iLoai(0)
{
}

GiaSuc::~GiaSuc(void)
{
}

class Bo :	public GiaSuc
{
public:
	Bo(void);
	~Bo(void);
	void Keu(void);
	int ChoSua(void);
	vector<GiaSuc*> SinhCon(void);
	string TenLoai(void);
};


int GiaSuc::LoaiGiaSuc(void)
{
	return m_iLoai;
}

#include <stdlib.h>
#include <time.h>
#include <iostream>

using namespace std;

Bo::Bo(void)
{
	m_iLoai = 1;
}

Bo::~Bo(void)
{
}

void Bo::Keu(void)
{
	cout << "Um bo" << endl;
}

int Bo::ChoSua(void)
{
	return rand() % 21;
}

vector<GiaSuc*> Bo::SinhCon(void)
{
	int socon = 1 + rand() % 8;
	vector<GiaSuc*> con;
	for (int i = 0; i < socon; i++)
		con.push_back(new Bo());
	return con;
}

string Bo::TenLoai(void)
{
	return "Bo";
}

class Cuu :
	public GiaSuc
{
public:
	Cuu(void);
	~Cuu(void);
	void Keu(void);
	int ChoSua(void);
	vector<GiaSuc*> SinhCon(void);
	string TenLoai(void);
};

Cuu::Cuu(void)
{
	m_iLoai = 2;
}

Cuu::~Cuu(void)
{
}

void Cuu::Keu(void)
{
	cout << "Bee bee" << endl;
}

int Cuu::ChoSua(void)
{
	return rand() % 6;
}

vector<GiaSuc*> Cuu::SinhCon(void)
{
	int socon = 1 + rand() % 8;
	vector<GiaSuc*> con;
	for (int i = 0; i < socon; i++)
		con.push_back(new Cuu());
	return con;
}

string Cuu::TenLoai(void)
{
	return "Cuu";
}
class De :
	public GiaSuc
{
public:
	De(void);
	~De(void);
	void Keu(void);
	int ChoSua(void);
	vector<GiaSuc*> SinhCon(void);
	string TenLoai(void);
};

using namespace std;

De::De(void)
{
	m_iLoai = 3;
}

De::~De(void)
{
}

void De::Keu(void)
{
	cout << "Hee hee" << endl;
}

int De::ChoSua(void)
{
	return rand() % 11;
}

vector<GiaSuc*> De::SinhCon(void)
{
	int socon = 1 + rand() % 8;
	vector<GiaSuc*> con;
	for (int i = 0; i < socon; i++)
		con.push_back(new De());
	return con;
}

string De::TenLoai(void)
{
	return "De";
}
int main()
{
	srand((unsigned)time(NULL));
	vector<GiaSuc*> nongtrai;
	int number;
	cin >> number;
	for (int i = 0; i < number; i++)
	{
		int l = rand() % 3;
		switch (l)
		{
		case 0:
			nongtrai.push_back(new Bo);
			break;
		case 1:
			nongtrai.push_back(new Cuu);
			break;
		case 2:
			nongtrai.push_back(new De);
			break;
		}
	}
	for (int i = 0; i < (int)nongtrai.size(); i++)
		nongtrai[i]->Keu();

	int sl = (int)nongtrai.size();
	for (int i = 0; i < sl; i++)
	{
		vector<GiaSuc*> t = nongtrai[i]->SinhCon();
		for (int j = 0; j < (int)t.size(); j++)
			nongtrai.push_back(t[j]);
	}
	cout << "So luong gia suc trong nong trai sau khi sinh con la: " << nongtrai.size() << endl;
	int sua = 0;
	for (int i = 0; i < (int)nongtrai.size(); i++)
		sua += nongtrai[i]->ChoSua();
	cout << "Tong sua: " << sua << endl << "Cac gia suc trong nong trai:" << endl;

	for (int i = 0; i < (int)nongtrai.size(); i++)
	{
		cout << nongtrai[i]->TenLoai() << endl;
	}
}

