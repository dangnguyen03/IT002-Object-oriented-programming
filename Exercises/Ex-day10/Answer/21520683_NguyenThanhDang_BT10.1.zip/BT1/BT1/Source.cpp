﻿#include <iostream>
#include <string>
using namespace std;
class SX;
class VP;
class NhanVien
{
private:
	string name;
	string date;
	float salary;
public:
	NhanVien(){}
	NhanVien(string a, string b, int c)
	{
		name = a;
		date = b;
		salary = c;
	}
	friend class SX;
	friend class VP;
};
class SX : public NhanVien	
{
private:
	int numberProduct;
public :
	float Sarary()
	{
		return  salary + numberProduct * 5000;
	}
};
class SX : public NhanVien
{
private:
	int numberWork;
public:
	float Salary()
	{
		return salary + numberWork * 100000;
	}
};

void main()
{
	  // Đề bị lỗi thiếu yêu cầu, nên nó yêu cầu như thế nào thì em đã làm như thế đó 
}