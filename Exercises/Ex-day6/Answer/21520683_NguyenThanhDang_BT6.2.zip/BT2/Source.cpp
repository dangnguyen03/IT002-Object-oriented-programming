#include "Header.h"
int main() {
	TamGiac a[100];
	int number;
	cout << "Nhap so tam giac: ";
	cin >> number;
	for (int i = 0; i < number; i++)
	{
		a[i].Input();
	}
	for (int i = 0; i < number; i++)
	{
		cout << "Tao do tam giac thu " << i + 1 << " : \n";
		a[i].Output();
	}
	float maxs = a[0].DienTich(), maxc = a[0].Chuvi();
	int x=0;
	for (int i = 0; i < number; i++)
	{
		if (maxc < a[i].Chuvi()) {
			maxc = a[i].Chuvi();
			x = i;
		}
	}
	cout << "Chu vi lon nhat la tam giac thu "<<x+1 << endl;
	a[x].Output();
	cout << "Voi chu vi la: " << maxc << endl;
	x = 0;
	for (int i = 0; i < number; i++)
	{
		if (maxs < a[i].DienTich()) {
			maxs = a[i].DienTich();
			x = i;
		}
	}
	cout << "Dien tich lon nhat la tam giac thu "<<x+1 << endl;
	a[x].Output();
	cout << "Voi dien tich: " << maxs << endl;
	cout << "Nhap vao vec to tinh tien. ";
	Point vecto;
	vecto.Input();
	for (int i = 0; i < number; i++)
	{
		cout << "Tam giac thu " << i + 1 << " sau khi tinh tien: \n";
		a[i].TinhTien(vecto);
		a[i].Output();
	}
	return 0;
}