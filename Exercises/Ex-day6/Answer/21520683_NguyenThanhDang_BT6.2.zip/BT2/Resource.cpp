#include "Header.h"
Point::Point() {
	x = 0;
	y = 0;
}
Point::Point(float xx, float yy) {
	x = xx;
	y = yy;
}
Point::Point(Point& a) {
	x = a.x;
	y = a.y;
}
void Point::Input() {
	cout << "Input point: ";
	cin >> x >> y;
}
void Point::Ouput() {
	cout << '(' << x << ',' << y << ')' << endl;
}
void Point::tinhtien(Point a) {
	x += a.x;
	y += a.y;
}
float Point::Distance(Point a) {
	return sqrt(pow((x - a.x), 2) + pow((y - a.y), 2));
}
void TamGiac::Input() {
	cout << "Nhap diem thu nhat. "; A.Input();
	cout << "Nhap diem thu hai. "; B.Input();
	cout << "Nhap diem thu ba. "; C.Input();
}
void TamGiac::Output() {
	cout << "Diem thu nhat: "; A.Ouput();
	cout << "Diem thu hai: "; B.Ouput();
	cout << "Diem thu ba: "; C.Ouput();
}
void TamGiac::TinhTien(Point a) {
	A.tinhtien(a);   
	B.tinhtien(a);
	C.tinhtien(a);
}
float TamGiac::DienTich() {
	float a = A.Distance(B), b = A.Distance(C), c = B.Distance(C);
	float p = (a + b + c) / 2;
	return sqrt(p * (p - a) * (p - b) * (p - c));
}
float TamGiac::Chuvi() {
	return A.Distance(B) + A.Distance(C) + B.Distance(C);
}