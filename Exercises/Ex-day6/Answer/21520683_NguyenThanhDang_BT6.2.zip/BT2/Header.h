#pragma once
#include <iostream>
#include <cmath>
using namespace std;
class Point {
private:
	float x, y;
public:
	Point();
	Point(float xx, float yy);
	Point(Point& a);
	void Input();
	void Ouput();
	void tinhtien(Point a);
	float Distance(Point a);
	~Point() {}
};
class TamGiac {
	Point A, B, C;
public:
	TamGiac(){}
	TamGiac(Point AA, Point BB, Point CC) : A(AA), B(BB), C(CC) {}
	void Input();
	void Output();
	void TinhTien(Point a);
	float DienTich();
	float Chuvi();
	~TamGiac(){}
};

