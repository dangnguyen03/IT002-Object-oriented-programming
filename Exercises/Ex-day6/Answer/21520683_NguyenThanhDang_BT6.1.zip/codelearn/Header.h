#pragma once
#include <iostream>
#include <cmath>
using namespace std;
class Point {
private:
	float x, y;
public:
	Point();
	Point(float xx, float yy);
	Point(Point& a);
	void Input();
	void Ouput();
	void tinhtien(Point a);
	float Distance(Point a);
	~Point() {}
};
