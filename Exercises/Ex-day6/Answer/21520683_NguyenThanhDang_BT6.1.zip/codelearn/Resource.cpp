#include "Header.h"
#include <iostream>
#include <cmath>
using namespace std;
Point::Point() {
		x = 0;
		y = 0;
}
Point::Point(float xx, float yy) {
		x = xx;
		y = yy;
}
Point::Point(Point& a) {
		x = a.x;
		y = a.y;
}
void Point::Input() {
		cout << "Input point: ";
		cin >> x >> y;
}
void Point::Ouput() {
		cout << '(' << x << ',' << y << ')' << endl;
}
void Point::tinhtien(Point a) {
		x += a.x;
		y += a.y;
}
float Point:: Distance(Point a) {
		return sqrt(pow((x - a.x), 2) + pow((y - a.y), 2));
}