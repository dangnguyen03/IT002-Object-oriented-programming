#include "Header.h"
int main() {
	Point a[100];
	int number;
	cout << "Nhap so diem: ";
	cin >> number;
	for (int i = 0; i < number; i++)
	{
		a[i].Input();
	}
	for (int i = 0; i < number; i++)
	{
		a[i].Ouput();
	}
	float max = a[0].Distance(a[ 1]);
	float min = a[0].Distance(a[ 1]);
	int x = 0, y = 1;
	for (int i = 0; i < number-1; i++)
	{
		for (int  j = i+1; j < number ;j++)
		{
			if (max < a[i].Distance(a[j])) {
				max = a[i].Distance(a[j]);
				x = i;
				y = j;
			}
		}
	}
	cout << "Khoang cach lon nhat: " << max << " . Cua 2 diem: "; a[x].Ouput();
	cout << " va "; 
	a[y].Ouput(); 
	cout << endl;
	x = 0; y = 1;
	for (int i = 0; i < number - 1; i++)
	{
		for (int j = i + 1; j < number ;j++)
		{
			if (min > a[i].Distance(a[j])) {
				min = a[i].Distance(a[j]);
				x = i;
				y = j;
			}
		}
	}
	cout << "Khoang cach be nhat: " << min << " . Cua 2 diem: "; a[x].Ouput();
	cout << " va ";
	a[y].Ouput();
	cout << "Nhap vao vecto tinh tien. ";
	Point vecto;
	vecto.Input();
	for (int i = 0; i < number; i++)
	{
		a[i].tinhtien(vecto);
		a[i].Ouput();
	}
	cout << endl;
	return 0;
}
