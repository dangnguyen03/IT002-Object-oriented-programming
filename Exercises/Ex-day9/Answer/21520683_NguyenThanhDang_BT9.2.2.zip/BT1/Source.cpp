﻿#include<iostream>
#include <random>
#include <time.h>
using namespace std;
class Pedion;
class Zattacker;
class Carrier;
class Robot {
    int M; //mass = khoi luong
    int S;
    int P;
    int F;
    int E;
public:
    Robot() {
        M = 0;
        S = 10;
        P = 0;
        E = 0;
        F = 0;
    }
    void Output()
    {
        cout << "M= " <<M<< endl;
        cout << "E= " << M << endl;
        cout << "P= " << M << endl;
        cout << "F= " << M << endl;
        cout << "S= " << M << endl;
    }
    friend class Zattacker;
    friend class Pedion;
    friend class Carrier;
};

class Pedion : public  Robot {
public:
    Pedion() {
        srand((unsigned)time(NULL));
        M = 20;
        F = rand() % 5 + 1;
    }
    int SumOfEnergyConsumtion()
    {
        return M * S + (F + 1) * S / 2;
    }
    void Output(int pos)
    {
        cout << "ID of Pedion: " << pos << endl;
        cout << "Sum of Energy Consumtion: " << SumOfEnergyConsumtion() << endl;
        cout << '\n';
    }
};
class Zattacker :public Robot {
public:
    Zattacker()
    {
        M = 50;
        srand((unsigned)time(NULL));
        P = rand() % 11 + 20;
    }
    int SumOfEnergyConsumtion()
    {
        return M * S + P * P * S;
    }
    void Output(int pos)
    {
        cout << "ID of Zattacker: " << pos << endl;
        cout << "Sum of Energy Consumtion: " << SumOfEnergyConsumtion() << endl;
        cout << '\n';
    }
};

class Carrier : public Robot {
public:
    Carrier()
    {
        M = 30;
        srand((unsigned)time(NULL));
        E = rand() % 51 + 50;
    }
    int SumOfEnergyConsumtion()
    {
        return     M * S + 4 * E * S;;
    }
    void Output(int pos)
    {
        cout << "ID of Carrier: " << pos << endl;
        cout << "Sum of Energy Consumtion: " << SumOfEnergyConsumtion() << endl;
        cout << '\n';
    }
};
int Max(int a[], int n)
{
    int max = a[0];
    for (int i = 1; i < n; i++)
    {
        if (max < a[i])
            max = a[i];
    }
    return max;
}
class Big
{
    Pedion A[100];
    Zattacker B[100];
    Carrier C[100];
public :
    void Input(int& na, int& nb, int& nc)
    {
        cout << "Na= ";
        cin >> na;
        cout << "Nb= ";
        cin >> nb;
        cout << "Nc= ";
        cin >> nc;
    }
    void Output(int na, int nb, int nc)
    {
        for (int i = 0; i < na; i++)
        {
            cout << "Pedion: " << endl;
            A[i].Output(i+1);
        }
        for (int i = 0; i < nb; i++)
        {
            cout << "Zattacker: " << endl;
            B[i].Output(i+1);
        }
        for (int i = 0; i < nc; i++)
        {
            cout << "Carrier: " << endl;
            C[i].Output(i+1);
        }
    }
    /*void MaxB(int na, int nb, int nc)
    {
        int a[100], b[100], c[100];
        for (int i = 0; i < na; i++)
        {
            a[i] = A[i].SumOfEnergyConsumtion();
        }
        for (int i = 0; i < nb; i++)
        {
            b[i] = B[i].SumOfEnergyConsumtion();
        }
        for (int i = 0; i < nc; i++)
        {
            c[i] = C[i].SumOfEnergyConsumtion();
        }
        int max=  Max(a, na);
        int max2= Max(b, nb);
        int max3 = Max(c, nc);
        if (max < max2) max = max2;
        if (max < max3) max = max3;
        for (int i = 0; i < na; i++)
        {
            if (max ==A[i].SumOfEnergyConsumtion())

        }
    }*/
    void MaxB(int na, int nb, int nc)
    {
        int sum[3];
        int k = 0;
        for (int i = 0; i < na; i++)
        {
            sum[k] += A[i].SumOfEnergyConsumtion();
        }
        k++;
        for (int i = 0; i < nb; i++)
        {
            sum[k] += B[i].SumOfEnergyConsumtion();
        }
        k++;
        for (int i = 0; i < nc; i++)
        {
            sum[k] += C[i].SumOfEnergyConsumtion();
        }
        k++;
        int max = Max(sum, k);
        cout << "Max Consumtion: ";
        if (max == sum[0]) cout << "Pedion" << endl;
        if (max == sum[1]) cout << "Zattacker" << endl;
        if (max == sum[2]) cout << "Carrier" << endl;
    }
    int Total(int na, int nb, int nc)
    {
        int sum1 = 0, sum2 = 0, sum3 = 0;
        for (int i = 0; i < na; i++)
        {
            sum1 += A[i].SumOfEnergyConsumtion();
        }
        for (int i = 0; i < nb; i++)
        {
            sum2 += B[i].SumOfEnergyConsumtion();
        }
        for (int i = 0; i < nc; i++)
        {
            sum3 += C[i].SumOfEnergyConsumtion();
        }
        return sum1 + sum2 + sum3;
    }
};
void main()
{
    Big b;
    int na, nb, nc;
    b.Input(na, nb, nc);
    cout << "Result: " << endl;
    b.Output(na, nb, nc);  //Câu a
    b.MaxB(na, nb, nc);  //Câu b
    cout << "Total Energy: ";
    cout<<b.Total(na, nb, nc); //Câu c
}