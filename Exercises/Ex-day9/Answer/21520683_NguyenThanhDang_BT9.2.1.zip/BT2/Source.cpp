#include <iostream>
#include <string>
using namespace std;

class CaoDang;
class DaiHoc;
class Person
{
private:
	string iD;
	string name;
	string address;
	int tongSoTinChi;
	float dTB;
public:
	void Input()
	{
		cout << "ID = ";
		cin.ignore();
		getline(cin, iD);
		cout << "Ten: ";
		getline(cin, name);
		cout << "Dia chi: ";
		getline(cin, address);
		cout << "Tong so tin chi: ";
		cin >> tongSoTinChi;
		cout << "DTB: ";
		cin >> dTB;
	}
	void Output()
	{
		cout << "ID = " << iD << endl;
		cout << "Ten: " << name << endl;
		cout << "Dia chi: " << address << endl;
		cout << "Tong so tin chi: " << tongSoTinChi << endl;
		cout << "DTB: " << dTB << endl;
	}
	friend class CaoDang;
	friend class DaiHoc;
};
class CaoDang : public Person
{
private:
	float diemThiTotNghiep;
public:
	void Input()
	{
		Person::Input();
		cout << "Diem thi tot nghiep: ";
		cin >> diemThiTotNghiep;
	}
	void Output()
	{
		Person::Output();
		cout << "Diem thi tot nghiep: " << diemThiTotNghiep << endl;
	}
	bool Condition()
	{
		if (tongSoTinChi >= 120 && dTB >= 5 && diemThiTotNghiep >= 5)return true;
		return false;
	}
	float getDiemTrungBinh()
	{
		return dTB;
	}
};
class DaiHoc : public Person
{
private:
	string tenLuanVan;
	float diemLuanVan;
public:
	void Input()
	{
		Person::Input();
		cout << "Ten luan van: ";
		cin.ignore();
		getline(cin, tenLuanVan);
		cout << "Diem luan van: ";
		cin >> diemLuanVan;
	}
	void Output()
	{
		Person::Output();
		cout << "Ten luan van: " << tenLuanVan << endl;
		cout << "Diem luan van: " << diemLuanVan << endl;
	}
	bool Condition()
	{
		if (tongSoTinChi >= 170 && dTB >= 5 && diemLuanVan >= 5)return true;
		return false;
	}
	float getDiemLuanVan()
	{
		return diemLuanVan;
	}
};
class SinhVien
{
	CaoDang cao;
	DaiHoc dai;
public:
	static int count;
	void Input(int &choose)
	{
		cout << "Cao Dang 1, Dai Hoc 2: ";
		cin >> choose;
		switch (choose)
		{
		case 1:
		{
			cao.Input(); 
			if (cao.Condition()) count++;
			break;
		}
		case 2: 
		{
			dai.Input(); 
			if (dai.Condition()) count++;
			break; 
		}
		}
	}
	void Output(int choose)
	{
		switch (choose)
		{
		case 1: cao.Output(); break;
		case 2: dai.Output(); break;
		}
	}
	float getDiem(int choose)
	{
		if (choose == 1) return cao.getDiemTrungBinh();
		else return dai.getDiemLuanVan();
	}
};
int SinhVien::count = 0;
float Max(float a[], int n)
{
	float max = a[0];
	for (int i = 1; i < n; i++)
	{
		if (max < a[i]) max = a[i];
	}
	return max;
}
void main()
{
	SinhVien sinh[100];
	cout << "So sinh vien: ";
	int n;
	cin >> n;
	int choose[100];
	for (int i = 0; i < n; i++)
	{
		sinh[i].Input(choose[i]);
		cout << '\n';
	}
	cout << "So sinh vien du dieu kien: " << sinh[0].count <<  endl;

	float maxcd, maxdh;
	float CD[100], DH[100];
	int k = 0, t = 0;
	for (int i = 0; i < n; i++)
	{
		if (choose[i] == 1)
			CD[k++] = sinh[i].getDiem(choose[i]);
		if (choose[i] == 2)
			DH[t++] = sinh[i].getDiem(choose[i]);
	}
	maxcd = Max(CD, k);
	maxdh = Max(DH, t);
	cout << "Sinh vien cao dang co diem cao nhat: ";
	cout << maxcd << endl;
	for (int i = 0; i < n; i++)
	{
		if (sinh[i].getDiem(choose[i]) == maxcd) {
			sinh[i].Output(choose[i]);
		}
	}
	cout << '\n';
	cout << "Sinh vien dai hoc co diem cao nhat: ";
	cout << maxdh << endl;
	for (int i = 0; i < n; i++)
	{
		if (sinh[i].getDiem(choose[i]) == maxdh) {
			sinh[i].Output(choose[i]);
		}
	}
}