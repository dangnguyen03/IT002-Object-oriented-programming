#include<iostream>
#include "Header.h"
#include<vector>
using namespace std;
void Input(vector<Polygons*>& List) {
    int CatchKey;
    do {
        cout << "\tPress 1 to input Quadrangle.\n";
        cout << "\tPress 2 to input Triangle.\n";
        cout << "\tPress 3 to input Parallelogram.\n";
        cout << "\tPress 4 to input RectAngle.\n";
        cout << "\tPress 5 to input Square.\n";
        cout << "\tPress 6 to back to the main menu.\n";
        while (cin >> CatchKey && CatchKey != 1 && CatchKey != 2 && CatchKey != 3 && CatchKey != 4 && CatchKey != 5 && CatchKey != 6)
        {
            cout << "Just Press in range 1,2,3,4,5,6. Again: ";
        }
        switch (CatchKey)
        {
        case 1:
            List.push_back(new Quadrangle);
            List[List.size() - 1]->Set();
            break;
        case 2:
            List.push_back(new Triangle);
            List.back()->Set();
            break;
        case 3:
            List.push_back(new Parallelogram);
            List.back()->Set();
            break;
        case 4:
            List.push_back(new RectAngle);
            List.back()->Set();
            break;
        case 5:
            List.push_back(new Square);
            List.back()->Set();
            break;
        default:
            break;
        }
    } while (CatchKey != 6);
}
void Print(vector<Polygons*>& List) {
    cout << "-----Print List Polygons----\n";
    for (int i = 0; i < List.size(); i++) {
        List[i]->Print();
        cout << endl;
    }
    cout << "--------------------------\n";
}
void Move(vector<Polygons*>& List) {
    cout << "Input vector(x,y) to move: ";
    int x, y;
    cin >> x >> y;
    for (int i = 0; i < List.size(); i++) {
        List[i]->Move(x, y);
    }
}
int main() {
    vector<Polygons*> ListPolygons;
    ListPolygons.resize(0);
    int CatchKey;
    do {
        cout << "Manage Polygons: \n";
        cout << "\tPress 1 to input one kind Polygons.\n";
        cout << "\tPress 2 to print and move all list of Polygonss.\n";
        cout << "\tPress 3 to exit.\n";
        while (cin >> CatchKey && CatchKey != 1 && CatchKey != 2 && CatchKey != 3)
        {
            cout << "Just Press in range 1,2,3. Again: ";
        }
        switch (CatchKey)
        {
        case 1:
            Input(ListPolygons);
            break;
        case 2:
            Print(ListPolygons);
            char x;
            cout << "Move? (y,n): ";
            while (cin >> x && x != 'n' && x != 'y') {
                cout << "Just Press y or n!Again.\n";
            }
            if (x == 'y') {
                Move(ListPolygons);
            }
            break;
        default:
            break;
        }
    } while (CatchKey != 3);
    for (int i = 0; i < ListPolygons.size(); i++) {
        delete ListPolygons[i];
    }
    cout << "Thanks!";
    return 0;
}