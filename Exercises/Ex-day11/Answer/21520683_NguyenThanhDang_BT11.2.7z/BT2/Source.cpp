#include "Header.h"
#include<iostream>
#include<cmath>
using namespace std;
//Polygon definition
//Constructor and Destructor

Polygons::Polygons() {
    SetNumVertices(0);
    vector<Coordinate> coor;
    coor.resize(0);
    SetCoor(coor);
}
Polygons::Polygons(int num) {
    SetNumVertices(num);
    vector<Coordinate> coor;
    coor.resize(0);
    for (int i = 0; i < num; i++) {
        coor[i] = { 0,0 };
    }
    SetCoor(coor);
}
Polygons::~Polygons() {
}
//Setter
void Polygons::SetNumVertices(int num) {
    NumVertices = num;
}
void Polygons::SetCoor(vector<Coordinate> coor) {
    /*
    for(int i=0;i<GetNumVertices();i++){
        Coor[i]=coor[i];
    }
    */
    Coor = coor;
}
void Polygons::Set() {
    /*
    cout<<"Numbers of vertices: ";
    int num;
    cin>>num;
    SetNumVertices(num);
    */
    vector<Coordinate> coor;
    coor.resize(GetNumVertices());
    do {
        for (int i = 0; i < GetNumVertices(); i++) {
            cout << "Coordinate " << i + 1 << "(x,y): ";
            cin >> coor[i].x;
            cin >> coor[i].y;
        }
        SetCoor(coor);
    } while (Check() == 0);
}
//other method
void Polygons::Print() {
    vector<Coordinate> coor;
    coor = GetCoor();
    for (int i = 0; i < GetNumVertices(); i++) {
        cout << "( " << coor[i].x << " , " << coor[i].y << " )";
        if (i != GetNumVertices() - 1) {
            cout << "--";
        }
    }
}
bool Polygons::Check() {
    vector<Coordinate> coor;
    coor = GetCoor();
    for (int i = 0; i < GetNumVertices() - 1; i++) {
        for (int j = i + 1; j < GetNumVertices(); j++) {
            if (coor[i].x == coor[j].x && coor[i].y == coor[j].y) {
                cout << "Wrong Input! Again.\n";
                return false;
            }
        }
    }
    return true;
}
void Polygons::Move(int x, int y) {
    vector<Coordinate> coor;
    coor = GetCoor();
    for (int i = 0; i < GetNumVertices(); i++) {
        coor[i].x += x;
        coor[i].y += y;
    }
    SetCoor(coor);
}
//Quadrangle definition
//constructor and destructor
Quadrangle::Quadrangle() {
    SetNumVertices(Vertices);
}
Quadrangle::~Quadrangle() {
}
//Setter
void Quadrangle::Set() {
    Polygons::Set();
}
//other method
void Quadrangle::Print() {
    cout << "Quadrangle: ";
    Polygons::Print();
}

//Triangle definition
Triangle::Triangle() {
    SetNumVertices(Vertices);
}
Triangle::~Triangle() {
}
//Setter
void Triangle::Set() {
    Polygons::Set();
}
//other method
void Triangle::Print() {
    cout << "Triangle: ";
    Polygons::Print();
}

//Parallelogram definition
Parallelogram::Parallelogram() {
}
Parallelogram::~Parallelogram() {
}
//Setter
void Parallelogram::Set() {
    Quadrangle::Set();
}
//other method
void Parallelogram::Print() {
    cout << "Parallelogram: ";
    Polygons::Print();
}
//method for check
double MultiCoor(Coordinate c1, Coordinate c2) {
    return c1.x * c2.x + c1.y * c2.y;
}
double Module(Coordinate c1, Coordinate c2) {
    return sqrt(pow(c1.x - c2.x, 2) + pow(c1.y - c2.y, 2));
}
Coordinate VectorCoor(Coordinate c1, Coordinate c2) {
    Coordinate c;
    c.x = c1.x - c2.x;
    c.y = c1.y - c2.y;
    return c;
}
bool Parallelogram::Check() {
    Coordinate YAxis = { 0,1 };
    vector<Coordinate> c = GetCoor();
    vector<double> value;
    value.resize(0);
    for (int i = 0; i < 3; i++) {
        for (int j = i + 1; j < 4; j++) {
            if (MultiCoor(VectorCoor(c[i], c[j]), YAxis) == 0) {
                value.push_back(Module(c[i], c[j]));
            }

        }
    }
    if (value.size() == 2 && value[0] == value[1]) {
        return true;
    }
    else {
        cout << "Wrong input!Again.\n";
        return false;
    }
}


//RectAngle definition
RectAngle::RectAngle() {
}
RectAngle::~RectAngle() {
}
//Setter
void RectAngle::Set() {
    Quadrangle::Set();
}
//other method
void RectAngle::Print() {
    cout << "RectAngle: ";
    Polygons::Print();
}

bool RectAngle::Check() {
    Coordinate YAxis = { 0,1 };
    Coordinate XAxis = { 1,0 };
    vector<Coordinate> c = GetCoor();
    vector<double> Xvalue;
    vector<double> Yvalue;
    Xvalue.resize(0);
    Yvalue.resize(0);
    for (int i = 0; i < 3; i++) {
        for (int j = i + 1; j < 4; j++) {
            if (MultiCoor(VectorCoor(c[i], c[j]), YAxis) == 0) {
                Xvalue.push_back(Module(c[i], c[j]));
            }
            else if (MultiCoor(VectorCoor(c[i], c[j]), XAxis) == 0) {
                Yvalue.push_back(Module(c[i], c[j]));
            }
            else {
            }
        }
    }
    if (Xvalue.size() == Yvalue.size()) {
        return true;
    }
    else {
        cout << "Wrong input!Again.\n";
        return false;
    }
}


//Square definition
Square::Square() {
}
Square::~Square() {
}
//Setter
void Square::Set() {
    Quadrangle::Set();
}
//other method
void Square::Print() {
    cout << "Square: ";
    Polygons::Print();
}
bool Square::Check() {
    Coordinate YAxis = { 0,1 };
    Coordinate XAxis = { 1,0 };
    vector<Coordinate> c = GetCoor();
    vector<double> Xvalue;
    vector<double> Yvalue;
    Xvalue.resize(0);
    Yvalue.resize(0);
    for (int i = 0; i < 3; i++) {
        for (int j = i + 1; j < 4; j++) {
            if (MultiCoor(VectorCoor(c[i], c[j]), YAxis) == 0) {
                Xvalue.push_back(Module(c[i], c[j]));
            }
            else if (MultiCoor(VectorCoor(c[i], c[j]), XAxis) == 0) {
                Yvalue.push_back(Module(c[i], c[j]));
            }
            else {
            }
        }
    }
    if (Xvalue.size() == Yvalue.size() && Xvalue[0] == Yvalue[0]) {
        return true;
    }
    else {
        cout << "Wrong input!Again.\n";
        return false;
    }
}
