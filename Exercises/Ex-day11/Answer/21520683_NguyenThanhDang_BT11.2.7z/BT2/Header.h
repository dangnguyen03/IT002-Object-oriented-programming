#pragma once
#include<vector>
using namespace std;
struct Coordinate
{
    int x;
    int y;
};

class Polygons
{
private:
    int NumVertices;
    vector<Coordinate> Coor;
public:
    Polygons();
    Polygons(int num);
    virtual ~Polygons();
    void SetNumVertices(int num);
    void SetCoor(vector<Coordinate> coor);
    virtual void Set();
    int GetNumVertices() { return NumVertices; }
    vector<Coordinate> GetCoor() { return Coor; }
    virtual void Print();
    virtual bool Check();
    void Move(int x, int y);
};
class Quadrangle :public Polygons
{
private:
    const int Vertices = 4;

public:
    Quadrangle();
    virtual ~Quadrangle();
    void Set();
    void Print();
};
class Triangle final :public Polygons
{
private:
    const int Vertices = 3;

public:
    Triangle();
    ~Triangle();
    void Set();
    void Print();
};
class Parallelogram final :public Quadrangle
{
public:
    Parallelogram();
    ~Parallelogram();
    void Set();
    bool Check();
    void Print();
};
class RectAngle :public Quadrangle
{
public:
    RectAngle();
    virtual ~RectAngle();
    void Set();
    bool Check();
    virtual void Print();
};
class Square final :public RectAngle
{
public:
    Square();
    ~Square();
    void Set();
    bool Check();
    void Print();
};
