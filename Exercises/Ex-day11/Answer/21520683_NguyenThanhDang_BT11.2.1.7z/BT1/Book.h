#pragma once
#include<string>
using namespace std;

class Book
{
private:
    string BookName;
    string Producer;
    int IssueYear;
    int NumPages;
    double Cost;
public:
    Book();
    Book(const string bookname, const string producer, int issueyear, int numpage, double cost);
    virtual ~Book();
    string GetBookName() { return BookName; }
    string GetProducer() { return Producer; }
    int GetIssueYear() { return IssueYear; }
    int GetNumPages() { return NumPages; }
    double GetCost() { return Cost; }
    void SetBookName(string bookname);
    void SetProducer(string producer);
    void SetIssueYear(int issueyear);
    void SetNumPages(int numpages);
    void SetCost(double cost);
    virtual void Set();
    virtual void Print();
};
class TextBook final :public Book
{
private:
    int Grade;
public:
    TextBook();
    TextBook(int grade);
    ~TextBook();
    int GetGrade() { return Grade; }
    void SetGrade(int grade);
    void Set();
    void Print();
};
class Novel final :public Book
{
private:
    string Kind;
public:
    Novel();
    Novel(const string kind);
    ~Novel();
    string GetKind() { return Kind; }
    void SetKind(string kind);
    void Set();
    void Print();
};
class Magazine final :public Book
{
private:
    string Period;
public:
    Magazine();
    Magazine(string period);
    ~Magazine();
    string GetPeriod() 
    {
        return Period; 
    }
    void SetPeriod(string period);
    void Set();
    void Print();
};
