﻿#include <iostream>
#include <string>
using namespace std;
class NhanVien
{
private:
	string name;
	string ngaySinh;
public:
	NhanVien(){}
	void Input() 
	{
		cout << "Nhap ten: ";
		cin.ignore();
		getline(cin, name);
		cout << "Ngay sinh:";
		getline(cin, ngaySinh);
	}
	void Output()
	{
		cout << "Ten: " << name << endl;
		cout << "Ngay sinh: " << ngaySinh << endl;
	}
};
class NVVP: public NhanVien
{
	int soNgayLamViec;
public:
	NVVP(){}
	void Input()
	{
		NhanVien::Input();
		cout << "So ngay lam: ";
		cin >> soNgayLamViec;
	}
	float getLuong()
	{
		return soNgayLamViec * 100000;
	}
	void Output()
	{
		NhanVien::Output();
		cout << "So ngay lam viec: " << soNgayLamViec << endl;
	}
};
class NVSX : public NhanVien
{
private:
	int soSanPham;
	float luongCanBan;
public:
	NVSX(){}
	void Input()
	{
		NhanVien::Input();
		cout << "Luong can ban: ";
		cin >> luongCanBan;
		cout << "So san pham: ";
		cin >> soSanPham;
	}
	float getLuong() {
		return luongCanBan + soSanPham * 5000;
	}
	void Output()
	{
		NhanVien::Output();
		cout << "Luong can ban: " << luongCanBan << endl;
		cout << "So san pham: " << soSanPham << endl;
	}
};
class Big
{
	NVVP vp;
	NVSX sx;
public:
	void Input(int &choose) {
		cout << "1 la nhan vien van phong, 2 la nhan vien san xuat: ";
		cin >> choose;
		switch (choose)
		{
		case 1:  {
			vp.Input();
			break;
		}
		case 2: 
		{
			sx.Input();
			break;
		}
		}
	}
	float getLuong(int choose)
	{
		switch (choose)
		{
		case 1: {
			return vp.getLuong();
		}
		case 2:
		{
			return sx.getLuong();
		}
		}
	}
	void Outputluong(int choose) {
		switch (choose)
		{
		case 1: {
			cout << vp.getLuong() << endl;
			break;
		}
		case 2:
		{
			cout << sx.getLuong() << endl;
			break;
		}
		}
	}
	void Output(int choose)
	{
		switch (choose)
		{
		case 1: {
			vp.Output();
			break;
		}
		case 2:
		{
			sx.Output();
			break;
		}
		}
	}
};
int main()
{
	Big bi[100];
	cout << "Nhap so nguoi muon nhap: ";
	int number;
	int choose[100];
	cin >> number;
	for (int  i = 0; i < number; i++)
	{
		bi[i].Input(choose[i]);
	}

	//Tính lương
	for (int i = 0; i < number; i++)
	{
		bi[i].Output(choose[i]);
		cout << "Luong "; bi[i].Outputluong(choose[i]);
	}

	//Xuất lương cao nhất và thấp nhất
	int result[100];
	for (int i = 0; i < number; i++)
	{
		result[i] = choose[i];
	}
	float min = bi[0].getLuong(choose[0]);
	int pos = 0;
	int chucnang = choose[0];
	for (int i = 1; i < number; i++)
	{
		if (min > bi[i].getLuong(choose[i]))
		{
			chucnang = choose[i];
			pos = i;
		}
	}
	cout << "Luong thap nhat: "; bi[pos].Output(chucnang);


	float max = bi[0].getLuong(choose[0]);
	 pos = 0;
	 chucnang = choose[0];
	for (int i = 1; i < number; i++)
	{
		if (max < bi[i].getLuong(choose[i]))
		{
			chucnang = choose[i];
			pos = i;
		}
	}
	cout << "Luong cao nhat: "; bi[pos].Output(chucnang);
}