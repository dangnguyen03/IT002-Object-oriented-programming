#include <iostream>
#include <string>
using namespace std;
class Person
{
	string name;
	int namSinh;
	string diaChi;
public:
	void Input()
	{
		cout << "Ten: ";
		cin.ignore();
		getline(cin, name);
		cout << "Dia chi: ";
		getline(cin, diaChi);
		cout << "Nam sinh: ";
		cin >> namSinh;
	}
	void Output()
	{
		cout << "Ten: " << name << endl;
		cout << "Dia chi: " << diaChi << endl;
		cout << "Nam sinh: " << namSinh << endl;
	}
};
class BacSi :public Person
{
private:
	string khoaChuyenMon;
	int soNamChuaBenh;
public:
	void Input()
	{
		Person::Input();
		cout << "Khoa chuyen mon: ";
		cin.ignore();
		getline(cin, khoaChuyenMon);
		cout << "So nam chua benh: ";
		cin >> soNamChuaBenh;
	}
	void Output()
	{
		Person::Output();
		cout << "Khoa chuyen mon: " << khoaChuyenMon << endl;
		cout << "So nam chua benh: " << soNamChuaBenh << endl;
	}
	string NoiLamViec()
	{
		return "Benh vien";
	}
};
class SinhVien :public Person
{
private:
	string MSSV;
	float DTB;
public:
	void Input()
	{
		Person::Input();
		cout << "MSSV: ";
		cin.ignore();
		getline(cin, MSSV);
		cout << "Diem trung binh: ";
		cin >> DTB;
	}
	void Output()
	{
		Person::Output();
		cout << "MSSV: " << MSSV << endl;
		cout << "Diem trung binh: " << DTB << endl;
	}
	string NoiLamViec()
	{
		return "Truong hoc";
	}
};
class CongNhan : public Person
{
private:
	float luongCoBan;
	int soNgayPhep;
	int soNamKinhNghiem;
public:
	void Input()
	{
		Person::Input();
		cout << "Luong co ban: ";
		cin >> luongCoBan;
		cout << "So Ngay Phep: ";
		cin >> soNgayPhep;
		cout << "So nam kinh nghiem: ";
		cin >> soNamKinhNghiem;
	}
	void Output()
	{
		Person::Output();
		cout << "Luong co ban: " << luongCoBan << endl;
		cout << "So Ngay Phep: " << soNgayPhep << endl;
		cout << "So nam kinh nghiem: " << soNamKinhNghiem << endl;
	}
	string NoiLamViec()
	{
		return "Nha May";
	}
};
class Casi :public Person
{
private:
	string dongNhac;
	int soShow;
	int soAlbum;
public:
	void Input()
	{
		Person::Input();
		cout << "Dong nhac: "; cin.ignore();
		getline(cin, dongNhac);
		cout << "So show: ";
		cin >> soShow;
		cout << "so Album: ";
		cin >> soAlbum;
	}
	void Output()
	{
		Person::Output();
		cout << "Dong nhac: " << dongNhac << endl;
		cout << "So show: " << soShow << endl;
		cout << "so Album: " << soAlbum << endl;
	}
	string NoiLamViec()
	{
		return "San khau";
	}
};
class BigPerson
{
private:
	SinhVien sinh;
	BacSi bac;
	Casi ca;
	CongNhan cong;
public:
	void Input(int &choose)
	{
		cout << "1 la sinh vien, 2 la bac si, 3 la ca si, 4 la cong nhan: ";
		cin >> choose;
		switch (choose)
		{
		case 1: sinh.Input(); break;
		case 2: bac.Input(); break;
		case 3: ca.Input(); break;
		case 4: cong.Input(); break;
		}
	}
	void Output(int choose)
	{
		switch (choose)
		{
		case 1: sinh.Output(); break;
		case 2: bac.Output(); break;
		case 3: ca.Output(); break;
		case 4: cong.Output(); break;
		}
	}
};
void main()
{
	BigPerson big[100];
	cout << "Nhap so doi tuong: ";
	int number;
	cin >> number;
	int choose[100];
	for (int i = 0; i < number; i++)
	{
		big[i].Input(choose[i]);
	}
	int type[4];
	for (int i = 0; i < 4; i++)
	{
		type[i] = 0;
	}
	int result[25];
	for (int i = 0; i < number; i++)
	{
		if (choose[i] == 1) type[0]++;
		else if (choose[i] == 2) type[1]++;
		else if (choose[i] == 3) type[2]++;
		else if (choose[i] == 4) type[3]++;
	}
	for (int i = 0; i < number; i++)
	{
		big[i].Output(choose[i]);
		cout << '\n';
	}
	cout << '\n';
	cout << "Sinh vien: " << type[0] << endl;
	cout << "Bac si: " << type[1] << endl;
	cout << "Ca si: " << type[2] << endl;
	cout << "Cong nhan: " << type[3] << endl;
}