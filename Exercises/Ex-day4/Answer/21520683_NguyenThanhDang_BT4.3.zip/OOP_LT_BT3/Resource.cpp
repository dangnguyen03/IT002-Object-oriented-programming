#include "Header.h"
void Candidate :: Input() {
	
		cout << "Nhap ma so:";
		cin.ignore();
		cin.getline(ma, 20);
		cout << "Nhap ten: ";
		cin.getline(name, 30);
		cout << "Nhap ngay thang nam sinh: ";
		getline(cin, dateYear);
		cout << "Nhap diem toan, van, anh: ";
		cin >> toan >> van >> anh;
}
void Candidate:: InputSV(Candidate* a, int num) {
		for (int i = 0; i < num; i++)
		{
			a[i].Input();
		}
}
void Candidate::Output(Candidate a) {
		cout << a.ma << '\t' << a.name << '\t' << endl;
}
float Candidate:: Total() {
		return toan + van + anh;
}
void Candidate::OutputSV(Candidate* a, int n) {
		for (int i = 0; i < n; i++)
		{
			if (a[i].Total() > 15) Output(a[i]);
		}
}
