#pragma once
#include <iostream>
#include <cmath>
#include <string>
using namespace std;
class Candidate {
private:
	char ma[20];
	char name[30];
	string dateYear;
	float toan, van, anh;
public:
	Candidate() {}
	void Input();
	void InputSV(Candidate* a, int num);
	void Output(Candidate a);
	float Total();
	void OutputSV(Candidate* a, int n);
};
