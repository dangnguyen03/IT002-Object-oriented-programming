#include "Header.h"

int main() {
	Candidate sv[100];
	int num;
	cout << "Nhap so sinh vien: ";
	cin >> num;
	sv->InputSV(sv, num);
	sv->OutputSV(sv,num);
	return 0;
}