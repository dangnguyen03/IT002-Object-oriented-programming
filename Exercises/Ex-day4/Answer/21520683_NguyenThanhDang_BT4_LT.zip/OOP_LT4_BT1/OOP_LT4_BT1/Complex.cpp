#include "Header.h"

ComplexNumber::ComplexNumber(){}
ComplexNumber::ComplexNumber(int a, int b) {
	numReal = a;
	numComplex = b;
}
void ComplexNumber::InputComplex() {
	cout << "Nhap phan thuc: ";
	cin >> numReal;
	cout << "Nhap phan ao: ";
	cin >> numComplex;
}
void ComplexNumber::OutputComplex() {
	if (numComplex == 0) cout << numReal;
	else if (numComplex > 0 && numReal != 0) cout << numReal << '+' << numComplex << 'i';
	else if (numReal == 0) cout << numComplex << 'i';
	else if (numReal != 0 && numComplex < 0) cout << numReal << numComplex << 'i';
}
float ComplexNumber::Module() {
	return (float)sqrt(pow(numReal, 2) + pow(numComplex, 2));
}
void ComplexNumber::OutputModule() {
	cout << "|z| ="<<fixed<<setprecision(2) << Module() << endl;
}
void ComplexNumber::CalculateComplex(ComplexNumber com1,ComplexNumber com2) {
	int numberMathSymbols = 3, i = 0;
	char mathSymbols[3] = { '+','-','*' };
	ComplexNumber com3;
	while (numberMathSymbols)
	{
		switch (numberMathSymbols)
		{
		case 3: {
			com3.numReal = com1.numReal + com2.numReal;
			com3.numComplex = com1.numComplex + com2.numComplex;
		}break;
		case 2: {
			com3.numReal = com1.numReal - com2.numReal;
			com3.numComplex = com1.numComplex - com2.numComplex;
		}break;
		case 1: {
			com3.numReal = com1.numReal * com2.numReal - com1.numComplex * com2.numComplex;
			com3.numComplex = com1.numReal * com2.numComplex + com2.numReal * com1.numComplex;
		}break;
		}
		--numberMathSymbols;
		cout << '('; com1.OutputComplex(); cout << ')';
		cout << mathSymbols[i]; ++i;
		cout << '('; com2.OutputComplex(); cout << ')'<< "= ";
		com3.OutputComplex(); cout << endl;
	}
}
