#include "Header.h"
int main() {
	ComplexNumber com1, com2;
	com1.InputComplex(); 
	com1.OutputModule(); 
	com2.InputComplex();
	com2.OutputModule();
	com1.CalculateComplex(com1,com2);
	return 0;
}