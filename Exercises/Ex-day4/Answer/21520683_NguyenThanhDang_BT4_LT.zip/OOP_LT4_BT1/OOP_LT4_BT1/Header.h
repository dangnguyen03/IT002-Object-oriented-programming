#pragma once
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
class ComplexNumber {
private:
	int numReal, numComplex;
public: 
	ComplexNumber();
	ComplexNumber(int a, int b);
	void InputComplex();
	void OutputComplex();
	void OutputModule();
	void CalculateComplex(ComplexNumber com1, ComplexNumber com2);
	float Module();
};