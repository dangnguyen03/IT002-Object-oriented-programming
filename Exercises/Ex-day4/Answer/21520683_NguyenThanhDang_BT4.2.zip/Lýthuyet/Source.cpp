#include <iostream>
#include <cmath>
using namespace std;
typedef class PhanSo {
private:
	int tuso, mauso;
public:
	void input();
	void output();
	friend void Pheptoan(PhanSo a, PhanSo b);
}PS;
int UCLN(int a, int b) {
	a = abs(a); b = abs(b);
	if (a == b) return b;
	else if (a > b) return UCLN(a - b, b);
	else return UCLN(a, b - a);
}
void Change(int &a, int &b) {
	if (b == 1) cout << a;
	else {
		if ((a > 0 && b < 0) || (a < 0 && b < 0)) {
			a *= a; b *= b;
		}
		cout << a << '/' << b;
	}
}
void Rutgon(int a, int b) {
	int k = UCLN(a, b);
	a /= k; b /= k;
}
void PS::input() {
	cin >> tuso >> mauso;
}
void PS::output() {
	cout << tuso << '/' << mauso;
}
void Pheptoan(PS a, PS b) {
	cout << "Nhap phep toan: ";
	char c; cin >> c;
	int tugia, maugia;
	switch (c)
	{
	case '+': {
		tugia = a.tuso * b.mauso + b.tuso * a.mauso;
		maugia = a.mauso * b.mauso;
	}break;
	case '-': {
		tugia = a.tuso * b.mauso - b.tuso * a.mauso;
		maugia = a.mauso * b.mauso;
	}break;
	case '*': {
		tugia = a.tuso * b.tuso;
		maugia = a.mauso * b.mauso;
	}break;
	case '/': {
		tugia = a.tuso * b.mauso;
		maugia = a.mauso * b.tuso;
	}break;
	default:
		break;
	}
	Change(tugia, maugia);
}
int main() {
	PS a, b;
	a.input(); b.input();
	Pheptoan(a, b);
	return 0;
}