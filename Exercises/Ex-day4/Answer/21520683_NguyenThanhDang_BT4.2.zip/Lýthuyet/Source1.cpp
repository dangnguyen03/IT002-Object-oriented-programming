#include <iostream>
using namespace std;
class Sophuc{};
class Phuc {
private: 
	int x, y;
public: 
	Phuc(int xx, int yy) {
		x = xx; y = yy;
	}
	friend class Sophuc;
};
class Sophuc {
private :
	Phuc a, b;
public: 
	Sophuc(int x, int y,int z,int t) : a(x, y),b(z,t) {};
	friend void input(Sophuc a);
	friend void Pheptoan(Sophuc a, Sophuc b);
};
void input(Sophuc a) {
	int x, y, z, t;
	cin >> x >> y >> z >> t;
	Sophuc(x, y, z, t);
}
void Pheptoan(Sophuc a, Sophuc b) {
	cout << "Nhap phep toan: "; char c;
	cin >> c;
	switch (c)
	{
	case '+': {
		
	}
		break;
	case '-': {

	}
		break;
	case '*': {

	}
		break;
	case '/': {

	}
		break;
	default:
		break;
	}
}
int main() {

	return 0;
}