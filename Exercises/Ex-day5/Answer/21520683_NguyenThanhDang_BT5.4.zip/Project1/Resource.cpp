#include "Header.h"
 
Time:: Time(int h, int m, int s) {
	hour = h;
	min = m;
	sec = s;
}
void Time::input() {
	cout << "Nhap gio, phut, giay: ";
	cin >> hour >> min >> sec;
}
void Time::output() {
	cout << "Thoi gian la: " << hour << ":" << min << ':' << sec << endl;
}
int Time::isRight() {
	if (hour > 24 || min > 60 || sec > 60) return 0;
	return 1;
}
void Time::Addsectime(int s) {
	Time a;
	Transectohour(a, s);
	this->hour += a.hour;
	this->min += a.min;
	this->sec += a.sec;
	if (this->sec >= 60) {
		this->sec -= 60;
		min += 1;
		if (min >= 60) {
			min -= 60;
			hour += 1;
			if (hour > 24) {
				hour %= 24;
			}
		}
	}
}
void Transectohour(Time& a, int s) {
	a.hour = s / 3600;
	a.min = (s - 3600 * a.hour) / 60;
	a.sec = s - 3600 * a.hour - 60 * a.min;
}
