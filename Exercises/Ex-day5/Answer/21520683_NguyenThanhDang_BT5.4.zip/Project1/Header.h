#pragma once
#include <iostream>
#include <cmath>
using namespace std;
class Time {
private:
	int hour, min, sec;
public:
	Time() {}
	Time(int h, int m, int s);
	void input();
	void output();
	int isRight();
	friend void Transectohour(Time& a, int s);
	void Addsectime(int s);
	~Time() {}
};
void Transectohour(Time& a, int s);
