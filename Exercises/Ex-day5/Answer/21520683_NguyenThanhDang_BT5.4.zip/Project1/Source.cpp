#include "Header.h"
int main() {
	Time a;
	a.input();
	if (a.isRight()) {
		int s;
		cout << "Nhap thoi gian them vao: ";
		cin >> s;
		a.Addsectime(s);
		a.output();
	}
	return 0;
}