#include "Header.h"
int main() {
	Stack a;
	int n;
	cin >> n;
	a.input(n);
	if (a.empty_stack()) cout << "Rong" << endl;
	else cout << "Khac rong" << endl;
	int t;
	cout << "Nhap phan tu muon them vao top: ";
	cin >> t;
	a.push_stack(t,n);
	cout << "Them 5 vao dau day: \n";
	a.output(n);
	cout << "\n Phan tu cao nhat la: ";
	cout << '\n' << a.top_stack() << endl;
	a.pop_stack(n);
	cout << "Xoa phan tu dau cao nhat: \n";
	a.output(n);
	return 0;
}