#include "Header.h"
void Stack::input(int n) {
	for (int i = n - 1; i >= 0; --i)
	{
		cin >> a[i];
	}
}
void Stack::output(int n) {
	for (int i = 0; i < n; i++)
	{
		cout << a[i] << "\t";
	}
}
int Stack::top_stack() {
	return a[0];
}
void Stack::pop_stack(int& n) {
	for (int i = 0; i < n - 1; i++)
	{
		a[i] = a[i + 1];
	}
	--n;
}
bool Stack::empty_stack() {
	if (a[0] == NULL) return 1;
	return 0;
}
void Stack::push_stack(int data, int& n) {
	for (int i = n - 1; i >= 0; i--)
	{
		a[i + 1] = a[i];
	}
	a[0] = data;
	n++;
}