#include "Header.h"
int main() {
	Queue a;
	int n;
	cout << "Nhap so phan tu: ";
	cin >> n;
	a.input(n);
	if (a.queue_empty(n)==0) {
		cout << "Rong";
	}
	else {
		int k;
		cout << "Nhap so phan tu muon them vao: ";
		cin >> k;
		for (int i = 0; i < k; i++)
		{
			int x;
			cin >> x;
			a.queue_push(x, n);
		}
		cout << "Hang doi moi la: \n";
		a.output(n);
		cout << "Do lon cua Queue:\t" << a.queue_size(n) << endl;
	}
	return 0;
}