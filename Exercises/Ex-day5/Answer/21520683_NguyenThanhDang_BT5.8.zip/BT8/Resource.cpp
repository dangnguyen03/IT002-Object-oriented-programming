#include "Header.h"
int Queue::queue_top() {
	return a[0];
}
void Queue::queue_push(int data, int& n) {
	a[n] = data;
	++n;
}
int Queue::queue_size(int n) {
	return n;
}
bool Queue::queue_empty(int n) {
	if (queue_size(n) == 0) return 0;
	return 1;
}
void Queue::queue_pop(int& n) {
	for (int i = 0; i < n - 1; i++)
	{
		a[i] = a[i + 1];
	}
	--n;
}
void Queue::input(int n) {
	for (int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
}
void Queue::output(int n) {
	int t = n;
	for (int i = 0; i < t; i++)
	{
		cout << queue_top() << endl;
		queue_pop(n);
	}
}