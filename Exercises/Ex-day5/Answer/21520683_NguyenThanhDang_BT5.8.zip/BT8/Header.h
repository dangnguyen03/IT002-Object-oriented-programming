#pragma once
#include <iostream>
using namespace std;
class Queue {
private:
	int a[100];
public:
	Queue() {}
	void input(int n);
	void output(int n);
	int queue_top();
	void queue_push(int data, int& n);
	int queue_size(int n);
	bool queue_empty(int n);
	void queue_pop(int& n);
	~Queue(){}
};
