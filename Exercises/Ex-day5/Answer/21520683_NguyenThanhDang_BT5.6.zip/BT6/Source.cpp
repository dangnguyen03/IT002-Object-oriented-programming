#include "Header.h"
int main() {
	Stack a;
	int num;
	cout << "Nhap so muon phan tich thanh thua so nguyen to: ";
	cin >> num; int nu = num;
	int n = 1;
	for (int  i = 2; i <=num; i++)
	{
		if (soNguyenTo(i)) {
			while (num%i==0)
			{
				num /= i;
				a.push_stack(i, n);
			}
		}
	}
	int t = n;
	int i = 0;
	cout << nu << " = ";
	while (--t )
	{
		cout << a.top_stack();
		a.pop_stack(n);
		if (n-1!=0)
		cout << " * ";
	}
}