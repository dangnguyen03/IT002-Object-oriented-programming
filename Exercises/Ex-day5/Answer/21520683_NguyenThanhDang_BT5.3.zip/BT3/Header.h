#pragma once
#include<iostream>
using namespace std;
class diem
{
private:
	float x, y;
public:
	diem();
	diem(float, float);
	~diem(void);
	void nhap();
	void xuat();
	void setx(float);
	void sety(float);
	diem vector(diem);
	float getx();
	float gety();
	void setxy(float, float);
	void tinhtien(float a, float b);
	void quay(float);
};
class dagiac
{
private:
	diem A[100];
public:
	dagiac();
	~dagiac(void);
	void nhap(int n);
	void xuat(int n);
	void tinhtien(float a, float b,int n);
	void quay(float,int);
	void thuphong(float,int);
};
