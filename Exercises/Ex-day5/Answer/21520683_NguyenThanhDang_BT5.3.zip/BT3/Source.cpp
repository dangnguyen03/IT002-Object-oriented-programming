#include "Header.h"	
void main()
{
	float x, y, rad, k;
	dagiac a[100];
	cout << "Nhap so dinh: ";
	int n;
	cin >> n;
	a->nhap(n);
	a->xuat(n);
	cout << "\n\ntinh tien theo vector v(x,y):\nx="; cin >> x;
	cout << "y="; cin >> y;
	a->tinhtien(x, y, n);
	a->xuat(n);
	cout << "\nquay goc: rad="; cin >> rad;
	a->quay(rad, n);
	a->xuat(n);
	cout << "\nnhap he so thu phong k="; cin >> k;
	a->thuphong(k, n);
	a->xuat(n);
	system("pause");
}