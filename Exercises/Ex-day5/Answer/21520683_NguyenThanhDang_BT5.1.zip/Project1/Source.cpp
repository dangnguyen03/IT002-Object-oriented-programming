#include<iostream>
#include <amp_graphics.h>
using namespace std;
class Point {
private:
	float x, y;
public:
	Point(){}
	void Input() {
		cout << "Input x: ";
		cin >> x;
		cout << "Input y: ";
		cin >> y;
	}
	float HoanhDo() {
		return x;
	}
	float TungDo() {
		return y;
	}
	Point TinhTien(Point a) {
		Point Tt;
		Tt.x = this->x + a.x;
		Tt.y = this->y + a.y;
		return Tt;
	}
	void Output() {
		cout << '(' << x << ',' << y << ')';
	}
	void VeDoHoa();
};
void main()
{
	return 0;
}
