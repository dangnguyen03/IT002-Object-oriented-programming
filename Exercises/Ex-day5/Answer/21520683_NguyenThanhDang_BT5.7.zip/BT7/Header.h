#pragma once
#include <iostream>
using namespace std;
class Stack {
	int a[100];
public:
	void input(int n);
	void output(int n);
	int top_stack();
	void pop_stack(int& n);
	bool empty_stack();
	void push_stack(int data, int& n);
};
int soNguyenTo(int a);
char Thapluc(int a);