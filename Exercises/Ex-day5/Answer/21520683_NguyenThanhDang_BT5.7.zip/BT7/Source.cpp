#include "Header.h"
int main() {
	Stack a;
	int num;
	cout << "Nhap so muon chuyen: ";
	cin >> num;
	cout << "Chuyen sang he nhi phan: ";
	int n = 1;
	int nhiphan = num;
	while (nhiphan!=0)
	{
		int t = nhiphan % 2;
		nhiphan /= 2;
		a.push_stack(t, n);
	}
	int k = n - 1;
	for (int i = 0; i < k; i++)
	{
		cout << a.top_stack();
		a.pop_stack(n);
	}
	cout << endl;
	int batphan = num;
	n = 1;
	cout << "\nChuyen sang bat phan:\t";
	while (batphan!=0)
	{
		int t = batphan % 8;
		batphan /= 8;
		a.push_stack(t, n);
	}
	 k = n - 1;
	for (int i = 0; i < k; i++)
	{
		cout << a.top_stack();
		a.pop_stack(n);
	}
	cout << endl;
	int thapluc = num;
	n = 1;
	cout << "\nChuyen sang thap luc: \t";
	while (thapluc!=0)
	{
		int t = thapluc % 16;
		thapluc /= 16;
		a.push_stack(t, n);
	}
	k = n - 1;
	for (int i = 0; i < k; i++)
	{
		if (a.top_stack()<=10)
		cout << a.top_stack();
		else 
		{
			cout << Thapluc(a.top_stack());
		}
		a.pop_stack(n);
	}
	cout << endl;
	return 0;
}